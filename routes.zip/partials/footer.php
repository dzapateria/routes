
<p>Footer partial default</p>
<!-- debug helpers outputs -->
<?php
if(DEV) include ROOT . '/libs/info.php';
?>

<script src="<?=JS?>codigo.js?v=<?=DEV?time():date("d.m.y")?>"></script>
</body>
</html>