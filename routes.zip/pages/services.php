
<h1>pagina servicios</h1>

<img src="https://picsum.photos/id/237/200/300" alt="">
<img src="https://picsum.photos/200" alt="">

<img src="<?=FILES?>200.jpg" alt="">

